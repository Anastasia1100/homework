Rails.application.routes.draw do
  get '/champion', to: 'players#champions'
end
