Player.create(name: 'Anatoly', last_name: 'Karpov', birth_year: '1951', years_of_championship: '1975—1985 ')
Player.create(name: 'Robert', last_name: 'Fischer', birth_year: '1943', death_year: '2008', years_of_championship: '1972—1975  ')

