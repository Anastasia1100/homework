class PlayersController < ApplicationController
  def rules

  end

  def champions
    @players = Player.all
  end

  def home

  end
end
