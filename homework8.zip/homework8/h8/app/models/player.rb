class Player < ApplicationRecord
end
