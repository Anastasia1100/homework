class PlayersController < ApplicationController
  def rules
  @players = Player.new
  end

  def champions
    @players = Player.all
  end

  def home
  @players = Player.new(name: params[:player][:name])
  end
end
