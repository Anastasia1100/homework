class Player < ApplicationRecord
  validates :name, presence: true
  validates :name, length: { minimum: 3 }
  validates :last_name, presence: true
  validates :last_name, length: { minimum: 3 }
end
