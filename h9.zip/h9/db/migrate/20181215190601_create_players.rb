class CreatePlayers < ActiveRecord::Migration[5.2]
  def change
    create_table :players do |t|
      t.string :name
      t.string :last_name
      t.integer :birth_year
      t.integer :death_year
      t.integer :years_of_championship

      t.timestamps
    end
  end
end
