Rails.application.routes.draw do
  get '/champion', to: 'players#champions'
  get 'player/rules'
  get 'player/champions'
  get 'player/home'
  post 'player/home'
end
