module ChessHelper
end
