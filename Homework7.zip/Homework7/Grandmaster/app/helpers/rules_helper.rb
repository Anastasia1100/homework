module RulesHelper
end
