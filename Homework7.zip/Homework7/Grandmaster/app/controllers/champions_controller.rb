class ChampionsController < ApplicationController
  def chess

  end
end
