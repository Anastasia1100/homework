class RulesController < ApplicationController
  def info

  end
end
