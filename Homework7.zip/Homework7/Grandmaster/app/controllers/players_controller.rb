class PlayersController < ApplicationController
  before_action :set_champions

  def game
    @players_waiting = %w(Garry\ Kasparov Magnus\ Carlsen Sergey\ Karjakin)
  end


  def champions

  end

  def home
    @time = Time.now
  end

  def set_champions
    @champions ||= %w(Kasparov Carlsen Karjakin).sample
  end
end
