Rails.application.routes.draw do
get '/champions' , to: 'champions#chess'
get '/game', to: 'players#game'
get '/champions', to: 'players#champions'
get '/rules' , to: 'rules#info'
root 'players#home'
end
