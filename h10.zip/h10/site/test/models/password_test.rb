require 'test_helper'

class PasswordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
