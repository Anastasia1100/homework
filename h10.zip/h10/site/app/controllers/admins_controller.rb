class AdminsController < ApplicationController
  def signup

  end
  def check
     admin = Admin.find_by_name(params[:admin][:name])
     login(admin.name) if admin && admin.password
      redirect_to rooth_path
    end
  end
end
