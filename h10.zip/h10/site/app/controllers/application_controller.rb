class ApplicationController < ActionController::Base
  include AplicationHelper
  def signup(name)
    session [:name] = 'name'
  end
end
