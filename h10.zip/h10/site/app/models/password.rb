class Password < ApplicationRecord
end
