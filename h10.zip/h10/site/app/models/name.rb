class Name < ApplicationRecord
end
