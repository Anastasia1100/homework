module ApplicationHelper
  def login(name)
    session[:name] = name
  end
  def current_user
    session[:name]
  end
  def loggin?()
   !session[:name].nil?
  end
end
